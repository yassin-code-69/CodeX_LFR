# Independent Open-Risk Regression Reproductions (LFR PRO V3.3)

These tests were **not shipped with the submitted firmware**. They are independent scenario and fault-injection checks used in the audit. Their source code does not modify the original LFR firmware. These are simulated tests, **not** motor/STM32 hardware validation.

Files:
- `test_open_risks.cpp`: all-black marker, connected fan, premature script route advance, false finish, missed finish, white-line black start pad.
- `test_adc_calibration_abort.cpp`: dead ADC during motorized auto-sweep; verifies that motors run through the 900 ms sweep despite the ADC fault latch.
- `test_adc_init_timeout.cpp` and `mock_stm32f1_calstuck.h`: *audit-only* model with stuck ADC reset and calibration bits. Illustrates missing init-timeout fault latch.
- `run_audit_repros.sh`: Linux/macOS/WSL runner, using `g++` and the source project's existing `tests/stubs`.

## Run

After extracting this folder, in a terminal:

```sh
sh audit_reproduction/run_audit_repros.sh /path/to/CodeX_LFR
```

The destination `/tmp/lfr-v33-audit-repros` holds temporary executables. None of the repository files are edited. Do not flash these programs to the robot.
