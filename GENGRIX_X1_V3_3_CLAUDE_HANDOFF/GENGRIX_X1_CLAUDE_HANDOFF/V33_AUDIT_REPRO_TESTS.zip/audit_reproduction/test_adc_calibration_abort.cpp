#include <cassert>
#include <cstdio>
#define LFR_UI_TEST_ACCESS 1
#include "LFR_PRO_V3.ino"
int main() {
  for(int i=0;i<64;++i)mockDigital[i]=HIGH;
  motors.begin();sensor.begin();
  mockAdc1Instance.dead=true;
  uint32_t before=millis();
  performAutoSweep();
  uint32_t spent=millis()-before;
  assert(sensor.adcFault());
  assert(spent>=900);
  assert(mockPwm[PA0]==0 && mockPwm[PA1]==0 && mockPwm[PB8]==0 && mockPwm[PB9]==0);
  std::printf("REPRO #6: ADC dead at AUTO SWEEP start -> adcFault=%d, motors stopped only after %lums (no early abort)\n",sensor.adcFault(),(unsigned long)spent);
}
