#include <cstdio>
#include <cassert>
#include "Arduino.h"
#include "LFR_Sensor.h"
#include "LFR_Control.h"
using namespace lfr;
static SensorFrame line(){SensorFrame f={};f.pos=0;f.seen=true;f.center=true;f.active=2;f.confidence=800;return f;}
static SensorFrame full(){SensorFrame f=line();f.fullMarker=true;f.active=14;f.leftEdge=true;f.rightEdge=true;return f;}
static SensorFrame junction(){SensorFrame f=line();f.junction=true;f.leftEdge=true;f.active=8;return f;}
int main(){
 Settings s=defaultSettings();Calibration cal={};Sensor sen;sen.begin();
 for(int i=0;i<SENSOR_COUNT;++i){cal.white[i]=160;cal.black[i]=3000;mockMuxADC[i]=3000;}
 sen.buildNormTable(cal);SensorFrame sf={};sen.read(sf,cal,true,s);
 assert(sf.fullMarker && !sf.junction && sf.active==14);
 printf("REPRO #1: all black -> fullMarker=%d junction=%d active=%d\n",sf.fullMarker,sf.junction,sf.active);
 for(int i=0;i<SENSOR_COUNT;++i) mockMuxADC[i]=(i<=7?3000:160);
 sen.resetTracking();sen.read(sf,cal,true,s);
 assert(sf.seen && sf.leftEdge && sf.center && sf.groups==1 && !sf.junction);
 printf("REPRO #2: connected left+center fan -> junction=%d groups=%d active=%d\n",sf.junction,sf.groups,sf.active);
 s.navMode=uint8_t(NavMode::Script);s.routeCount=1;s.route[0]=uint8_t(RouteStep::Left);
 Controller route;route.start(0,0);
 for(uint32_t t=3;t<=9;t+=3)route.tick(junction(),s,t,0.003f);
 assert(route.state()==DriveState::JunctionAdvance && route.routeUsed()==1);
 printf("REPRO #3: routeUsed=%d before turn (state=%s)\n",route.routeUsed(),route.status());
 // No reacquisition: pivot fails, but routeUsed remains consumed.
 SensorFrame lost={};
 route.tick(lost,s,60,0.003f);route.tick(lost,s,1100,0.003f);
 assert(route.state()==DriveState::Fault && route.routeUsed()==1);
 printf("REPRO #3b: failed pivot -> state=%s routeUsed=%d\n",route.status(),route.routeUsed());
 s=defaultSettings();s.finishOn=1;
 Controller c;c.start(0,0);
 for(uint32_t t=3;t<=2700;t+=3)c.tick(line(),s,t,0.003f);
 for(uint32_t t=2703;t<=2736;t+=3)c.tick(full(),s,t,0.003f);
 assert(c.state()==DriveState::Finished);
 printf("REPRO #4: broad black crossing after centered approach -> %s (can be false finish)\n",c.status());
 c.start(0,0);
 for(uint32_t t=3;t<=2700;t+=3)c.tick(line(),s,t,0.003f);
 SensorFrame glitch=line();glitch.center=false;glitch.pos=2150;
 c.tick(glitch,s,2703,0.003f);
 c.tick(full(),s,2706,0.003f);
 for(uint32_t t=2709;t<=3621;t+=3)c.tick(full(),s,t,0.003f);
 assert(c.state()==DriveState::Fault);
 printf("REPRO #5: valid finish but one approach-frame glitch -> %s after black pad\n",c.status());
 for(int i=0;i<SENSOR_COUNT;++i) mockMuxADC[i]=3000;
 s=defaultSettings();s.lineMode=uint8_t(LineMode::White);
 sen.resetTracking();sen.read(sf,cal,true,s);
 assert(!sf.seen && !sf.fullMarker);
 printf("REPRO #8: WHITE line mode with all-black 30cm pad -> seen=%d fullMarker=%d (cannot arm there)\n",sf.seen,sf.fullMarker);
 puts("Open-risk reproductions complete (these are demonstrations of existing behaviors, not patched tests).");
}
