#!/bin/sh
set -eu
ROOT=${1:-.}
HERE=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
ROOT=$(CDPATH= cd -- "$ROOT" && pwd)
OUT=${TMPDIR:-/tmp}/lfr-v33-audit-repros
mkdir -p "$OUT"
cd "$ROOT"
CXX=${CXX:-g++}
FLAGS='-std=c++17 -Wall -Wextra -Werror -O2 -Itests/stubs -ILFR_PRO_V3'
$CXX $FLAGS tests/stubs/mock_arduino.cpp LFR_PRO_V3/LFR_Sensor.cpp LFR_PRO_V3/LFR_Control.cpp LFR_PRO_V3/LFR_PID.cpp "$HERE/test_open_risks.cpp" -o "$OUT/open_risks"
"$OUT/open_risks"
$CXX $FLAGS -DSTM32F1xx -include tests/stubs/mock_stm32f1.h tests/stubs/mock_arduino.cpp LFR_PRO_V3/LFR_PID.cpp LFR_PRO_V3/LFR_Control.cpp LFR_PRO_V3/LFR_Sensor.cpp LFR_PRO_V3/LFR_Motor.cpp LFR_PRO_V3/LFR_Storage.cpp LFR_PRO_V3/LFR_OLED.cpp "$HERE/test_adc_calibration_abort.cpp" -o "$OUT/adc_calibration_abort"
"$OUT/adc_calibration_abort"
$CXX $FLAGS -DSTM32F1xx -include "$HERE/mock_stm32f1_calstuck.h" tests/stubs/mock_arduino.cpp LFR_PRO_V3/LFR_Sensor.cpp "$HERE/test_adc_init_timeout.cpp" -o "$OUT/adc_init_timeout"
"$OUT/adc_init_timeout"
