#include <cassert>
#include <cstdio>
#include "Arduino.h"
#include "LFR_Sensor.h"
using namespace lfr;
int main(){
 mockAdc1Instance.calStuck=true;
 Sensor sensor;sensor.begin();
 const bool resetStuck=(ADC1->CR2&ADC_CR2_RSTCAL)!=0;
 const bool calStuck=(ADC1->CR2&ADC_CR2_CAL)!=0;
 assert(resetStuck && calStuck);
 assert(!sensor.adcFault());
 printf("REPRO #7: ADC init calibration bits remain set (%d/%d), adcFault=%d (not latched)\n",resetStuck,calStuck,sensor.adcFault());
}
